from plugin import Plugin


class Plugin0(Plugin):
    """Doc"""

    def require(self):
        pass

    def complete(self):
        pass

    def alias(self):
        pass

    def run(self, jarvis, s):
        jarvis.say("exec")
