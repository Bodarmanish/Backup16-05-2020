from plugin import Plugin


class Plugin1(Plugin):
    """Test"""

    def require(self):
        pass

    def complete(self):
        pass

    def alias(self):
        pass

    def run(self, jarvis, s):
        pass


class Plugin2(Plugin):
    """Test"""

    def require(self):
        pass

    def complete(self):
        pass

    def alias(self):
        pass

    def run(self, jarvis, s):
        pass
